import os
import json

class Movies(object):
    _base_url = 'http://hhhshop.co:83/movie/{u}/{p}/{vid}.mkv'

    def __init__(self, u, p, path=None):
        self.u = u
        self.p = p
        self.contents = None
        self.path = path

    def fetch_contents(self):
        if not self.contents:
            with open(os.path.join(self.path, 'json/movies.json'), 'r') as f:
                self.contents = json.load(f)
        return self.contents

    def fetch_vid_url(self, vid):
        return self._base_url.format(u=self.u, p=self.p, vid=vid)

class TVSeries(object):
    _base_url = 'http://hhhshop.co:83/series/{u}/{p}/{vid}.mkv'

    def __init__(self, u, p, path=None):
        self.u = u
        self.p = p
        self.contents = None
        self.path = path

    def fetch_contents(self):
        if not self.contents:
            with open(os.path.join(self.path, 'json/tvseries.json'), 'r') as f:
                self.contents = json.load(f)
        return self.contents

    def fetch_vid_url(self, vid):
        return self._base_url.format(u=self.u, p=self.p, vid=vid)
