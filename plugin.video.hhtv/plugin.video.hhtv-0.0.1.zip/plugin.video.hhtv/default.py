from __future__ import unicode_literals

import sys,os
reload(sys)
sys.setdefaultencoding('utf-8')

import xbmc, xbmcgui
from xbmcgui import ListItem, Dialog
import xbmcplugin
from xbmcplugin import addDirectoryItem, endOfDirectory

from resources.lib.modules.addon import Addon
from resources.lib.modules import routing
from resources.lib.modules.log_utils import log
from resources.lib.modules.entities import Movies, TVSeries, SeriesArt

addon = Addon('plugin.video.hhtv', sys.argv)
addon_handle = int(sys.argv[1])
plugin = routing.Plugin()

AddonPath = addon.get_path()
IconPath = os.path.join(AddonPath , "resources/media/")
fanart = os.path.join(AddonPath + "/fanart.jpg")

_u = 'cC83tQaT'
_p = 'J4mu6VYu'

_movies = Movies(u=_u, p=_p, path=AddonPath)
_tvseries = TVSeries(u=_u, p=_p, path=AddonPath)
_seriesart = SeriesArt(path=AddonPath)

# Update path so that praw doesnt complain
sys.path.append(os.path.join(AddonPath, 'resources/lib/modules'))

def icon_path(filename):
    if 'http://' in filename:
        return filename
    return os.path.join(IconPath, filename)

# def index():
#     fname = '337951.mkv'
#     url = plugin.url_for(play, fname=fname)
#     addDirectoryItem(
#         plugin.handle,
#         url,
#         ListItem("test video"), True)
#     endOfDirectory(plugin.handle)

@plugin.route('/')
def index():
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(tv),
        ListItem("TV Shows"), True)
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(movies),
        ListItem("Movies"), True)
    endOfDirectory(plugin.handle)

@plugin.route('/tv')
def tv():
    if 'season' in plugin.args.keys():
        season = plugin.args['season'][0]
        seriesname = plugin.args['seriesname'][0]
        group = plugin.args['group'][0]
        for (episode, vid) in sorted(_tvseries.fetch_contents()[group][seriesname][season]):
            url = _tvseries.fetch_vid_url(vid)
            li = ListItem(
                "{} - {}x{}".format(seriesname, season, episode),
                iconImage=_seriesart.artwork_lookup(seriesname))
            addDirectoryItem(
                plugin.handle,
                plugin.url_for(play, url=url),
                li),
        endOfDirectory(plugin.handle)
        return

    if 'seriesname' in plugin.args.keys():
        seriesname = plugin.args['seriesname'][0]
        group = plugin.args['group'][0]
        for season in sorted(_tvseries.fetch_contents()[group][seriesname].keys()):
            if season == 'x':
                _, vid = _tvseries.fetch_contents()[group][seriesname]['x'][0]
                url = _tvseries.fetch_vid_url(vid)
                li = ListItem(
                    "Play {}".format(seriesname))
                addDirectoryItem(
                    plugin.handle, plugin.url_for(play, url=url), li)
            else:
                addDirectoryItem(
                    plugin.handle,
                    plugin.url_for(tv, group=group, seriesname=seriesname, season=season),
                    ListItem(
                        "{} - Season {}".format(seriesname, season)),
                    True)
        endOfDirectory(plugin.handle)
        return

    if 'group' in plugin.args.keys():
        group = plugin.args['group'][0]
        for seriesname in sorted(_tvseries.fetch_contents()[group].keys()):
            li = ListItem(seriesname, iconImage=_seriesart.artwork_lookup(seriesname))
            addDirectoryItem(
                plugin.handle,
                plugin.url_for(tv, group=group, seriesname=seriesname),
                li, True)
        endOfDirectory(plugin.handle)
        return

    for group in sorted(_tvseries.fetch_contents().keys()):
        addDirectoryItem(
            plugin.handle,
            plugin.url_for(tv, group=group),
            ListItem(group), True)
    endOfDirectory(plugin.handle)
    return

@plugin.route('/movies')
def movies():
    if 'group' in plugin.args.keys():
        group = plugin.args['group'][0]
        for name, v in sorted(_movies.fetch_contents()[group].items(), key=lambda x: x[0]):
            url = _movies.fetch_vid_url(v['vid'])
            li = ListItem(name, iconImage=v['logo'])
            addDirectoryItem(
                plugin.handle,
                plugin.url_for(play, url=url),
                li)
        endOfDirectory(plugin.handle)
        return
    for group in sorted(_movies.fetch_contents().keys()):
        if group == '':
            continue
        addDirectoryItem(
            plugin.handle,
            plugin.url_for(movies, group=group),
            ListItem(group), True)
    endOfDirectory(plugin.handle)
    return

@plugin.route('/play')
def play():
    stream_url = plugin.args['url'][0]
    log("Playing {}".format(stream_url))
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem("test", path=stream_url)
    xbmc.Player().play(item=stream_url, listitem=play_item)

if __name__ == '__main__':
    plugin.run()
