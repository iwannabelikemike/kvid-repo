from bs4 import BeautifulSoup as bss
from resources.lib.modules import client
from resources.lib.modules import log_utils

class IMDBLists(object):
    def __init__(self, imdb_user):
        self.imdb_user = imdb_user
        self.imdb_users_watchlist_url = 'http://www.imdb.com/user/ur{userid}/'
        self.imdb_list_url = 'http://www.imdb.com/list/{list_id}?sort=alpha,asc&st_dt=&mode=detail&page=1'

    def get_lists(self):
        ulist = []
        url = self.imdb_users_watchlist_url.format(userid=self.imdb_user)
        result = client.request(url)
        soup = bss(result)
        items = soup.findAll("div", { "class" : "user-list" })
        for item in items:
            list_id = item['id']
            list_name = item.find("a", {"class": "list-name"}).get_text()
            ulist.append({'name': list_name, 'id': list_id})
        return ulist

    def get_list_contents(self, list_id):
        results_list = []
        url = self.imdb_list_url.format(list_id=list_id)
        result = client.request(url)
        soup = bss(result)
        for li in soup.findAll("div", {"class": "lister-item mode-detail"}):
            title = li.find("h3", {"class": "lister-item-header"}).find('a').getText()
            year = li.find("span", {"class": "lister-item-year"}).getText()
            rating = li.find("span", {"class": "rating-rating"}).find("span", {"class": "value"}).getText()
            plot = li.find("p", {"class": ""}).getText().strip()
            imdb = li.find("div", {"class": "lister-item-image"}).find("img")['data-tconst']
            poster = li.find("div", {"class": "lister-item-image"}).find("img")['loadlate']
            results_list.append({'title': title, 'year': year, 'rating': rating,
                                 'plot': plot, 'imdb': imdb, 'poster': poster})
        return results_list
