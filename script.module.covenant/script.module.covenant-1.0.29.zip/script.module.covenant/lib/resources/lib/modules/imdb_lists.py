from bs4 import BeautifulSoup as bss
from resources.lib.modules import (log_utils, client)

class IMDBLists(object):
    """
    Representation of IMDB lists. Use this to fetch tv show and movie lists
    for a given imdb user id.
    """

    def __init__(self, imdb_user, title_type):
        """
        Parameters:
        imdb_user: The user id for the imdb account (numbers only)
        title_type: One of ['movie', 'tvSeries']. This is used to filter the list
        """
        self.imdb_user = imdb_user
        self.imdb_users_watchlist_url = 'http://www.imdb.com/user/ur{userid}/'
        self.imdb_list_url = ('http://www.imdb.com/list/{listid}'
            '?sort=alpha,asc&st_dt=&mode=detail&page=1&title_type={titletype}')
        self.title_type = title_type
        assert title_type in ['movie', 'tvSeries']

    def get_lists(self):
        """
        Return all the imdb lists for this user.
        """
        if not self.imdb_user:
            return []
        ulist = []
        url = self.imdb_users_watchlist_url.format(userid=self.imdb_user)
        result = client.request(url)
        soup = bss(result, "html.parser")
        items = soup.findAll("div", { "class" : "user-list" })
        for item in items:
            list_id = item['id']
            list_name = item.find("a", {"class": "list-name"}).get_text()
            if self.title_type == 'tvSeries':
                url = ("action=tvshowPage&url=imdbTvShowList"
                    "&listId={}").format(list_id)
            else:
                url = ("action=moviePage&url=imdbMovieList"
                    "&listId={}").format(list_id)
            ulist.append({'name': list_name, 'id': list_id, 'url': url, 'tvdb': '0'})
        return ulist

    def get_list_contents(self, list_id):
        """
        Return each item in the list
        """
        if not self.imdb_user:
            return []
        results_list = []
        url = self.imdb_list_url.format(listid=list_id, titletype=self.title_type)
        log_utils.log('get_list_contents')
        log_utils.log(url)
        result = client.request(url)
        soup = bss(result, "html.parser")
        for li in soup.findAll("div", {"class": "lister-item mode-detail"}):
            title = li.find("h3", {"class": "lister-item-header"}).find('a').getText()
            year = li.find("span", {"class": "lister-item-year"}).getText()
            rating = li.find("span", {"class": "rating-rating"}).find("span", {"class": "value"}).getText()
            plot = li.find("p", {"class": ""}).getText().strip()
            imdb = li.find("div", {"class": "lister-item-image"}).find("img")['data-tconst']
            poster = li.find("div", {"class": "lister-item-image"}).find("img")['loadlate']
            results_list.append({
                    'title': title,
                    'originaltitle': title,
                    'year': year,
                    'rating': rating,
                    'plot': plot,
                    'imdb': imdb,
                    'poster': poster,
                    'tvdb': '0'
                })
        return results_list
